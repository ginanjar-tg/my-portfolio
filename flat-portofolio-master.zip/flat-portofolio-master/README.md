# Portofolio Animation

## **Dibuat menggunakan**
- HTML 5
- CSS 3
- [Bootstrap 5](https://getbootstrap.com/docs/5.0/getting-started/introduction/)
- [AOS Library](https://github.com/michalsnik/aos)
- [GSAP](https://greensock.com/gsap/)

## See Also

<a href="https://www.instagram.com/_wiklapanduu">
    <img alt="Instagram = _wiklapandu" src="https://img.shields.io/badge/wiklapandu-258F76?logo=instagram&logoColor=white&style=flat">
</a>
<a href="https://github.com/wiklapandu">
    <img alt="Github = wiklapandu" src="https://img.shields.io/badge/wiklapandu-gray?logo=github&style=flat">
</a>
<a href="https://www.instagram.com/wwwikla/">
    <img alt="Instagram = wwikla" src="https://img.shields.io/badge/wwwikla-258F76?logo=instagram&logoColor=white&style=flat">
</a>
<a href="https://www.instagram.com/wwwikla/">
    <img alt="Instagram = wwikla" src="https://img.shields.io/badge/wiklapandu-blue?logo=twitter&logoColor=white&style=flat">
</a>
<a href="https://wiklapandu.github.io/portofolio-animation/">
    <img alt="portofolio live" src="https://img.shields.io/badge/portofolio-live-red">
</a>